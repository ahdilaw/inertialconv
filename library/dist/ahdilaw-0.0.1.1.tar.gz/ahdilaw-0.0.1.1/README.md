Plugin Library for Inertial Filters for Deep Convolutional Networks
Submitted by Labiba Shahab and Ahmed Wali in submission for the Deep Learning Coursework at the Lahore University of Management Sciences (LUMS) in Spring Offering 2025.

Date: 2025-05-06 PKT